import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const initializeDiseases = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if diseases are already initialized
    const existingDiseases = await ctx.db.query("diseases").first();
    if (existingDiseases) {
      return "Diseases already initialized";
    }

    const diseases = [
      {
        name: "Sífilis Primária",
        category: "lesoes",
        agent: "Treponema pallidum",
        symptoms: ["lesao_genital", "lesao_indolor"],
        lesion_characteristics: {
          type: ["ulcera", "cancro_duro"],
          location: ["genital", "anal", "oral"],
          pain: false,
          number: ["unica", "multiplas"]
        },
        additional_symptoms: ["linfadenopatia_inguinal"],
        diagnostic_tests: ["VDRL", "FTA-ABS", "Campo escuro", "Treponema pallidum por PCR"],
        treatment_notes: "Penicilina G benzatina 2.4 milhões UI, IM, dose única",
        complications: ["Progressão para sífilis secundária", "Sífilis terciária", "Neurossífilis"],
        visual_criteria: [
          "Úlcera única, bem delimitada, com bordas elevadas e endurecidas",
          "Base limpa, não purulenta, com fundo vermelho brilhante",
          "Lesão indolor à palpação",
          "Linfadenopatia inguinal bilateral não dolorosa",
          "Lesão pode aparecer 10-90 dias após exposição"
        ],
        image_description: "Úlcera genital única, circular, com bordas bem definidas e elevadas, base limpa e avermelhada, aspecto característico de cancro duro"
      },

      {
        name: "Sífilis Secundária",
        category: "lesoes",
        agent: "Treponema pallidum",
        symptoms: ["lesao_genital", "erupcao_cutanea", "lesoes_palmo_plantares", "manchas_avermelhadas"],
        lesion_characteristics: {
          type: ["roséola_sifilítica", "sifílides_papulosas", "condiloma_plano", "manchas_planas", "manchas_elevadas"],
          location: ["genital", "palmas", "plantas", "tronco", "face", "mucosas", "couro_cabeludo"],
          pain: false,
          number: ["multiplas", "disseminadas"]
        },
        additional_symptoms: ["febre", "mal_estar", "cefaleia", "linfadenopatia_generalizada", "alopecia_areata", "placas_mucosas", "placas_acinzentadas_mucosas", "linfonodos_inchados_sensiveis", "perda_cabelo_couro_cabeludo", "perda_pelos_faciais"],
        diagnostic_tests: ["VDRL reagente (títulos altos)", "FTA-ABS", "TPPA", "Treponema pallidum por PCR"],
        treatment_notes: "Penicilina G benzatina 2.4 milhões UI, IM, semanal por 3 semanas",
        complications: ["Progressão para sífilis terciária", "Neurossífilis", "Sífilis cardiovascular", "Reação de Jarisch-Herxheimer"],
        visual_criteria: [
          "Erupção cutânea: manchas avermelhadas que não coçam, planas ou ligeiramente elevadas",
          "Roséola sifilítica: máculas eritematosas não pruriginosas no tronco",
          "Sifílides papulosas: pápulas eritematosas descamativas",
          "Lesões palmo-plantares patognomônicas (palmas das mãos e plantas dos pés)",
          "Condiloma plano: lesões vegetantes úmidas em áreas intertriginosas",
          "Placas mucosas: lesões esbranquiçadas na mucosa oral",
          "Placas acinzentadas podem aparecer na boca ou outras mucosas",
          "Alopecia em clareira (moth-eaten appearance) no couro cabeludo",
          "Perda de pelos faciais em alguns casos",
          "Linfadenopatia generalizada: linfonodos inchados e sensíveis ao toque",
          "Sintomas sistêmicos: dor de cabeça, febre e mal-estar acompanham a erupção"
        ],
        image_description: "Múltiplas lesões cutâneas: erupção avermelhada no tronco, sifílides papulosas e lesões características nas palmas das mãos e plantas dos pés, com placas acinzentadas nas mucosas"
      },

      {
        name: "Sífilis Terciária",
        category: "lesoes",
        agent: "Treponema pallidum",
        symptoms: ["lesao_genital", "gomas_sifilíticas", "lesoes_cardiovasculares"],
        lesion_characteristics: {
          type: ["gomas", "ulceras_profundas", "lesoes_destrutivas"],
          location: ["genital", "pele", "ossos", "sistema_nervoso", "cardiovascular"],
          pain: false,
          number: ["unica", "multiplas"]
        },
        additional_symptoms: ["sintomas_neurologicos", "sintomas_cardiovasculares", "deformidades_osseas"],
        diagnostic_tests: ["VDRL", "FTA-ABS", "TPPA", "Punção lombar (neurossífilis)", "Ecocardiograma", "Radiografia óssea"],
        treatment_notes: "Penicilina G cristalina 18-24 milhões UI/dia EV por 10-14 dias (neurossífilis) ou Penicilina G benzatina 2.4 milhões UI, IM, semanal por 3 semanas",
        complications: ["Neurossífilis (tabes dorsalis, paralisia geral)", "Sífilis cardiovascular (aortite, aneurisma)", "Gomas destrutivas", "Incapacidade permanente"],
        visual_criteria: [
          "Gomas sifilíticas: nódulos que ulceram e cicatrizam com fibrose",
          "Lesões destrutivas em pele, mucosas e ossos",
          "Perfuração do palato duro (goma palatina)",
          "Deformidades nasais (nariz em sela)",
          "Sinais neurológicos: pupilas de Argyll Robertson",
          "Sinais cardiovasculares: sopro de insuficiência aórtica",
          "Cicatrizes atróficas características"
        ],
        image_description: "Gomas sifilíticas: lesões nodulares que evoluem para úlceras profundas com bordas bem definidas e tendência à cicatrização central"
      },

      {
        name: "Condiloma Acuminado (HPV)",
        category: "lesoes",
        agent: "Papilomavírus Humano (HPV) - tipos 6, 11, 16, 18",
        symptoms: ["lesao_genital", "verrugas_genitais", "lesoes_vegetantes", "aparecimento_verrugas"],
        lesion_characteristics: {
          type: ["verrugas", "lesoes_vegetantes", "papulas_queratosicas", "verrugas_pequenas", "verrugas_grandes", "aspecto_couve_flor"],
          location: ["genital", "anal", "oral", "perianal", "boca"],
          pain: false,
          number: ["multiplas", "agrupadas", "coalescentes", "unicas"]
        },
        additional_symptoms: ["prurido_local", "sangramento_lesoes", "odor_local", "coceira", "desconforto", "dor_regiao_afetada", "sangramento_dependendo_regiao"],
        diagnostic_tests: ["Exame clínico", "Colposcopia", "Peniscopia", "Anuscopia", "Biópsia", "PCR para HPV", "Captura híbrida"],
        treatment_notes: "Podofilotoxina 0,15% (uso domiciliar) ou Imiquimod 5% ou Ácido tricloroacético 80-90% ou Crioterapia ou Eletrocauterização",
        complications: ["Transformação maligna (câncer cervical, anal, peniano)", "Obstrução uretral", "Papilomatose respiratória recorrente", "Impacto psicossocial"],
        visual_criteria: [
          "Aparecimento de verrugas que podem ser pequenas ou grandes, únicas ou múltiplas",
          "Aspecto característico de 'couve-flor' das verrugas",
          "Lesões vegetantes com superfície irregular e papilomatosa",
          "Verrugas surgem principalmente na região genital e anal",
          "Em casos mais raros, podem aparecer na boca",
          "Coloração rósea a acastanhada das lesões",
          "Podem coalescer formando placas extensas",
          "Localização preferencial em áreas de atrito",
          "Teste do ácido acético positivo (lesões ficam esbranquiçadas)",
          "Podem ser planas ou exofíticas (sésseis ou pediculadas)"
        ],
        image_description: "Múltiplas verrugas com aspecto papilomatoso tipo 'couve-flor', de coloração rósea, que podem ser pequenas ou grandes, únicas ou múltiplas, localizadas na região genital"
      },
      
      {
        name: "Herpes Genital (HSV-1/HSV-2)",
        category: "lesoes",
        agent: "Vírus Herpes Simplex tipo 1 ou 2",
        symptoms: ["lesao_genital", "lesao_dolorosa", "vesiculas"],
        lesion_characteristics: {
          type: ["vesiculas", "ulceras_rasas", "crostas"],
          location: ["genital", "anal", "oral"],
          pain: true,
          number: ["multiplas", "agrupadas"]
        },
        additional_symptoms: ["febre", "mal_estar", "disuria", "linfadenopatia_inguinal"],
        diagnostic_tests: ["PCR para HSV", "Cultura viral", "Sorologia HSV-1/HSV-2", "Teste de Tzanck"],
        treatment_notes: "Aciclovir 400mg VO 3x/dia por 7-10 dias ou Valaciclovir 1g VO 2x/dia por 7-10 dias",
        complications: ["Recidivas frequentes", "Transmissão neonatal", "Meningite asséptica", "Retenção urinária"],
        visual_criteria: [
          "Vesículas agrupadas em base eritematosa",
          "Evolução para úlceras rasas e dolorosas",
          "Lesões múltiplas, pequenas (2-4mm)",
          "Formação de crostas na fase de cicatrização",
          "Sintomas prodrômicos: formigamento, queimação"
        ],
        image_description: "Vesículas agrupadas em base avermelhada, algumas rompidas formando úlceras rasas e dolorosas, com aspecto característico do herpes genital"
      },

      {
        name: "Clamídia",
        category: "corrimento",
        agent: "Chlamydia trachomatis",
        symptoms: ["corrimento_vaginal", "corrimento_uretral"],
        discharge_characteristics: {
          color: ["amarelado", "esbranquicado"],
          odor: ["sem_odor", "odor_leve"],
          consistency: ["mucoso", "purulento"],
          amount: ["moderado", "abundante"]
        },
        additional_symptoms: ["disuria", "sangramento_pos_coito", "dor_pelvica"],
        diagnostic_tests: ["PCR para Chlamydia", "NAAT (Teste de amplificação de ácidos nucleicos)", "Cultura celular"],
        treatment_notes: "Azitromicina 1g VO dose única ou Doxiciclina 100mg VO 2x/dia por 7 dias",
        complications: ["Doença inflamatória pélvica (DIP)", "Infertilidade", "Gravidez ectópica", "Conjuntivite neonatal"],
        visual_criteria: [
          "Corrimento mucopurulento amarelado ou esbranquiçado",
          "Colo uterino friável com sangramento ao toque",
          "Eritema e edema do colo uterino",
          "Pode ser assintomática em até 80% dos casos",
          "Corrimento uretral em homens, geralmente matinal"
        ],
        image_description: "Corrimento vaginal mucopurulento amarelado, colo uterino eritematoso e friável com sinais de inflamação"
      },

      {
        name: "Gonorreia",
        category: "corrimento",
        agent: "Neisseria gonorrhoeae",
        symptoms: ["corrimento_vaginal", "corrimento_uretral", "corrimento_purulento"],
        discharge_characteristics: {
          color: ["amarelo_esverdeado", "amarelo"],
          odor: ["fetido", "forte"],
          consistency: ["purulento", "espesso"],
          amount: ["abundante"]
        },
        additional_symptoms: ["disuria", "urgencia_urinaria", "dor_pelvica"],
        diagnostic_tests: ["Cultura em meio Thayer-Martin", "PCR para gonorreia", "Coloração de Gram", "NAAT"],
        treatment_notes: "Ceftriaxona 500mg IM dose única + Azitromicina 1g VO (tratamento duplo)",
        complications: ["Doença inflamatória pélvica", "Artrite gonocócica", "Oftalmia neonatal", "Infertilidade"],
        visual_criteria: [
          "Corrimento purulento amarelo-esverdeado abundante",
          "Disúria intensa e urgência urinária",
          "Colo uterino muito eritematoso e friável",
          "Corrimento uretral purulento em homens",
          "Sintomas aparecem 2-7 dias após exposição"
        ],
        image_description: "Corrimento vaginal purulento amarelo-esverdeado abundante, colo uterino intensamente inflamado e eritematoso"
      },

      {
        name: "Tricomoníase",
        category: "corrimento",
        agent: "Trichomonas vaginalis",
        symptoms: ["corrimento_vaginal", "corrimento_espumoso"],
        discharge_characteristics: {
          color: ["amarelo_esverdeado", "verde"],
          odor: ["fetido", "forte"],
          consistency: ["espumoso", "bolhoso"],
          amount: ["abundante"]
        },
        additional_symptoms: ["prurido_intenso", "disuria", "dispareunia", "hiperemia_vulvar"],
        diagnostic_tests: ["Exame a fresco", "Cultura em meio Diamond", "PCR para Trichomonas", "Teste rápido"],
        treatment_notes: "Metronidazol 2g VO dose única ou 500mg VO 2x/dia por 7 dias",
        complications: ["Vaginite recorrente", "Parto prematuro", "Baixo peso ao nascimento", "Facilitação transmissão HIV"],
        visual_criteria: [
          "Corrimento espumoso amarelo-esverdeado característico",
          "Odor fétido intenso",
          "Colo uterino em 'morango' (petéquias punctiformes)",
          "Vulva e vagina intensamente eritematosas",
          "Prurido vulvar intenso"
        ],
        image_description: "Corrimento vaginal espumoso amarelo-esverdeado, colo uterino com aspecto em 'morango' e vulva eritematosa"
      },

      {
        name: "Vaginose Bacteriana",
        category: "corrimento",
        agent: "Gardnerella vaginalis e outras bactérias anaeróbias",
        symptoms: ["corrimento_vaginal", "odor_caracteristico"],
        discharge_characteristics: {
          color: ["acinzentado", "esbranquicado"],
          odor: ["peixe", "amina", "forte_apos_coito"],
          consistency: ["homogeneo", "fluido"],
          amount: ["moderado", "abundante"]
        },
        additional_symptoms: ["prurido_leve", "irritacao_vulvar"],
        diagnostic_tests: ["Critérios de Amsel", "Coloração de Gram", "pH vaginal >4.5", "Teste de KOH (whiff test)"],
        treatment_notes: "Metronidazol 500mg VO 2x/dia por 7 dias ou gel vaginal de metronidazol",
        complications: ["Recidivas frequentes", "DIP", "Parto prematuro", "Infecções pós-cirúrgicas"],
        visual_criteria: [
          "Corrimento homogêneo acinzentado aderente às paredes vaginais",
          "Odor característico de peixe, intensificado após coito",
          "pH vaginal >4.5",
          "Teste de KOH positivo (odor de amina)",
          "Ausência de sinais inflamatórios intensos"
        ],
        image_description: "Corrimento vaginal homogêneo acinzentado aderente às paredes vaginais, sem sinais inflamatórios intensos"
      },

      {
        name: "Candidíase Vulvovaginal",
        category: "corrimento",
        agent: "Candida albicans (principalmente)",
        symptoms: ["corrimento_vaginal", "prurido_intenso"],
        discharge_characteristics: {
          color: ["branco", "esbranquicado"],
          odor: ["sem_odor", "adocicado_leve"],
          consistency: ["grumoso", "tipo_queijo_cottage"],
          amount: ["variavel"]
        },
        additional_symptoms: ["prurido_vulvar_intenso", "ardor", "dispareunia", "hiperemia_vulvar"],
        diagnostic_tests: ["Exame a fresco com KOH", "Cultura para fungos", "pH vaginal <4.5", "Microscopia direta"],
        treatment_notes: "Fluconazol 150mg VO dose única ou antifúngicos tópicos (miconazol, clotrimazol)",
        complications: ["Candidíase vulvovaginal recorrente", "Fissuras vulvares", "Infecção secundária", "Vulvodínia"],
        visual_criteria: [
          "Corrimento branco grumoso tipo 'queijo cottage'",
          "Ausência de odor ou odor adocicado leve",
          "Vulva e vagina intensamente eritematosas",
          "Prurido vulvar intenso",
          "Placas esbranquiçadas aderentes na vagina"
        ],
        image_description: "Corrimento vaginal branco grumoso tipo queijo cottage, vulva eritematosa com placas esbranquiçadas aderentes"
      }
    ];

    for (const disease of diseases) {
      await ctx.db.insert("diseases", disease);
    }

    return "Diseases initialized successfully";
  },
});

export const getAllDiseases = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("diseases").collect();
  },
});

export const getDiseasesByCategory = query({
  args: { category: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("diseases")
      .filter((q) => q.eq(q.field("category"), args.category))
      .collect();
  },
});
