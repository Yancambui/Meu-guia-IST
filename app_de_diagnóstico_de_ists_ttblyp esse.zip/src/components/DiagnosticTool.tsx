import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { DiseaseInfo } from "./DiseaseInfo";

export function DiagnosticTool() {
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [dischargeInfo, setDischargeInfo] = useState({
    color: "",
    odor: "",
    consistency: "",
    amount: ""
  });
  const [lesionInfo, setLesionInfo] = useState({
    type: "",
    location: "",
    pain: undefined as boolean | undefined,
    number: ""
  });
  const [additionalSymptoms, setAdditionalSymptoms] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [showResults, setShowResults] = useState(false);

  const createConsultation = useMutation(api.consultations.createConsultation);
  const initializeDiseases = useMutation(api.diseases.initializeDiseases);
  const diseases = useQuery(api.diseases.getAllDiseases);
  const latestConsultation = useQuery(api.consultations.getLatestConsultation);

  const handleSymptomChange = (symptom: string, checked: boolean) => {
    if (checked) {
      setSymptoms([...symptoms, symptom]);
    } else {
      setSymptoms(symptoms.filter(s => s !== symptom));
    }
  };

  const handleAdditionalSymptomChange = (symptom: string, checked: boolean) => {
    if (checked) {
      setAdditionalSymptoms([...additionalSymptoms, symptom]);
    } else {
      setAdditionalSymptoms(additionalSymptoms.filter(s => s !== symptom));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (symptoms.length === 0) {
      toast.error("Selecione pelo menos um sintoma principal");
      return;
    }

    try {
      const consultationData = {
        symptoms,
        discharge_info: symptoms.some(s => s.includes("corrimento")) ? dischargeInfo : undefined,
        lesion_info: symptoms.some(s => s.includes("lesao") || s.includes("vesiculas") || s.includes("erupcao") || s.includes("verrugas") || s.includes("aparecimento") || s.includes("manchas")) ? lesionInfo : undefined,
        additional_symptoms: additionalSymptoms,
        notes: notes || undefined
      };

      await createConsultation(consultationData);
      
      toast.success("Análise realizada com sucesso!");
      setShowResults(true);
      
    } catch (error) {
      toast.error("Erro ao processar a consulta");
      console.error(error);
    }
  };

  const resetForm = () => {
    setSymptoms([]);
    setDischargeInfo({ color: "", odor: "", consistency: "", amount: "" });
    setLesionInfo({ type: "", location: "", pain: undefined, number: "" });
    setAdditionalSymptoms([]);
    setNotes("");
    setResults([]);
    setShowResults(false);
  };

  // Initialize diseases if not done yet
  if (diseases?.length === 0) {
    initializeDiseases();
  }

  const mainSymptoms = [
    { id: "corrimento_vaginal", label: "Corrimento vaginal", icon: "💧" },
    { id: "corrimento_uretral", label: "Corrimento uretral", icon: "💧" },
    { id: "corrimento_purulento", label: "Corrimento purulento", icon: "🟡" },
    { id: "corrimento_espumoso", label: "Corrimento espumoso", icon: "🫧" },
    { id: "lesao_genital", label: "Lesão genital", icon: "🔴" },
    { id: "lesao_indolor", label: "Lesão indolor", icon: "⚪" },
    { id: "lesao_dolorosa", label: "Lesão dolorosa", icon: "🔴" },
    { id: "vesiculas", label: "Vesículas", icon: "🔵" },
    { id: "erupcao_cutanea", label: "Erupção cutânea", icon: "🟠" },
    { id: "lesoes_palmo_plantares", label: "Lesões palmo-plantares", icon: "👐" },
    { id: "manchas_avermelhadas", label: "Manchas avermelhadas", icon: "🔴" },
    { id: "verrugas_genitais", label: "Verrugas genitais", icon: "🟤" },
    { id: "lesoes_vegetantes", label: "Lesões vegetantes", icon: "🌿" },
    { id: "aparecimento_verrugas", label: "Aparecimento de verrugas", icon: "🟫" },
    { id: "gomas_sifilíticas", label: "Gomas sifilíticas", icon: "⚫" },
    { id: "lesoes_cardiovasculares", label: "Lesões cardiovasculares", icon: "❤️" },
    { id: "odor_caracteristico", label: "Odor característico", icon: "👃" },
    { id: "prurido_intenso", label: "Prurido intenso", icon: "🔥" }
  ];

  const additionalSymptomsOptions = [
    { id: "disuria", label: "Disúria (dor ao urinar)", icon: "💧" },
    { id: "dispareunia", label: "Dispareunia (dor durante relação)", icon: "💔" },
    { id: "dor_pelvica", label: "Dor pélvica", icon: "⚡" },
    { id: "sangramento_pos_coito", label: "Sangramento pós-coito", icon: "🩸" },
    { id: "febre", label: "Febre", icon: "🌡️" },
    { id: "mal_estar", label: "Mal-estar geral", icon: "😷" },
    { id: "cefaleia", label: "Cefaleia", icon: "🤕" },
    { id: "linfadenopatia_inguinal", label: "Linfadenopatia inguinal", icon: "🔍" },
    { id: "linfadenopatia_generalizada", label: "Linfadenopatia generalizada", icon: "🔍" },
    { id: "urgencia_urinaria", label: "Urgência urinária", icon: "⚡" },
    { id: "hiperemia_vulvar", label: "Hiperemia vulvar", icon: "🔴" },
    { id: "irritacao_vulvar", label: "Irritação vulvar", icon: "🔥" },
    { id: "alopecia_areata", label: "Alopecia areata", icon: "💇" },
    { id: "placas_mucosas", label: "Placas mucosas", icon: "👄" },
    { id: "placas_acinzentadas_mucosas", label: "Placas acinzentadas nas mucosas", icon: "👄" },
    { id: "linfonodos_inchados_sensiveis", label: "Linfonodos inchados e sensíveis", icon: "🔍" },
    { id: "perda_cabelo_couro_cabeludo", label: "Perda de cabelo no couro cabeludo", icon: "💇" },
    { id: "perda_pelos_faciais", label: "Perda de pelos faciais", icon: "💇" },
    { id: "sintomas_neurologicos", label: "Sintomas neurológicos", icon: "🧠" },
    { id: "sintomas_cardiovasculares", label: "Sintomas cardiovasculares", icon: "❤️" },
    { id: "deformidades_osseas", label: "Deformidades ósseas", icon: "🦴" },
    { id: "prurido_local", label: "Prurido local", icon: "🔥" },
    { id: "sangramento_lesoes", label: "Sangramento das lesões", icon: "🩸" },
    { id: "odor_local", label: "Odor local", icon: "👃" },
    { id: "coceira", label: "Coceira", icon: "🔥" },
    { id: "desconforto", label: "Desconforto", icon: "😣" },
    { id: "dor_regiao_afetada", label: "Dor na região afetada", icon: "⚡" },
    { id: "sangramento_dependendo_regiao", label: "Sangramento (dependendo da região)", icon: "🩸" }
  ];

  if (showResults) {
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Resultados da Análise
                </h2>
                <p className="text-gray-600 mt-1">Diagnósticos diferenciais baseados nos sintomas informados</p>
              </div>
              <button
                onClick={resetForm}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium shadow-sm"
              >
                Nova Consulta
              </button>
            </div>
          </div>
          
          <div className="p-6 space-y-4">
            {latestConsultation?.results && latestConsultation.results.length > 0 ? (
              latestConsultation.results.map((result, index) => (
                <div key={index} className="border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-bold text-xl text-gray-900">{result.disease}</h3>
                    <span className={`px-4 py-2 rounded-full text-sm font-bold ${
                      result.probability >= 70 ? 'bg-red-100 text-red-800 border border-red-200' :
                      result.probability >= 50 ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' :
                      'bg-green-100 text-green-800 border border-green-200'
                    }`}>
                      {result.probability}% compatibilidade
                    </span>
                  </div>
                  
                  <div className="text-sm text-gray-700 mb-4">
                    <p className="font-semibold mb-2 text-gray-900">Critérios correspondentes:</p>
                    <ul className="space-y-2">
                      {result.matching_criteria.map((criteria: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-blue-500 mt-1">✓</span>
                          <span>{criteria}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <DiseaseInfo diseaseName={result.disease} />
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.29-1.009-5.824-2.562M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <p className="text-gray-500 text-lg">
                  Nenhuma correspondência encontrada com os sintomas informados.
                </p>
                <p className="text-gray-400 text-sm mt-2">
                  Considere revisar os sintomas ou consultar outras fontes diagnósticas.
                </p>
              </div>
            )}
          </div>
          
          <div className="p-6 bg-amber-50 border-t border-amber-200">
            <div className="flex items-start gap-3">
              <svg className="w-6 h-6 text-amber-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
              <div>
                <p className="text-amber-800 font-semibold">Importante - Uso Clínico</p>
                <p className="text-amber-700 text-sm mt-1">
                  Esta ferramenta é apenas um auxílio ao diagnóstico. Sempre considere o quadro clínico completo, 
                  exames complementares e diretrizes clínicas atualizadas para o diagnóstico definitivo. 
                  A avaliação médica especializada é fundamental.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
          Nova Consulta Diagnóstica
        </h2>
        <p className="text-gray-600 mt-1">Selecione os sintomas observados para análise diagnóstica diferencial</p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-8">
        {/* Main Symptoms */}
        <div>
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
            Sintomas Principais
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {mainSymptoms.map((symptom) => (
              <label key={symptom.id} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={symptoms.includes(symptom.id)}
                  onChange={(e) => handleSymptomChange(symptom.id, e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span className="text-lg">{symptom.icon}</span>
                <span className="text-sm font-medium text-gray-700">{symptom.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Discharge Characteristics */}
        {symptoms.some(s => s.includes("corrimento")) && (
          <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
            <h3 className="text-lg font-bold text-blue-900 mb-4 flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17v4a2 2 0 002 2h4M13 5l4 4" />
              </svg>
              Características do Corrimento
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-blue-800 mb-2">Cor</label>
                <select
                  value={dischargeInfo.color}
                  onChange={(e) => setDischargeInfo({...dischargeInfo, color: e.target.value})}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="branco">Branco</option>
                  <option value="esbranquicado">Esbranquiçado</option>
                  <option value="amarelado">Amarelado</option>
                  <option value="amarelo">Amarelo</option>
                  <option value="amarelo_esverdeado">Amarelo-esverdeado</option>
                  <option value="verde">Verde</option>
                  <option value="acinzentado">Acinzentado</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-blue-800 mb-2">Odor</label>
                <select
                  value={dischargeInfo.odor}
                  onChange={(e) => setDischargeInfo({...dischargeInfo, odor: e.target.value})}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="sem_odor">Sem odor</option>
                  <option value="odor_leve">Odor leve</option>
                  <option value="fetido">Fétido</option>
                  <option value="forte">Forte</option>
                  <option value="peixe">Odor de peixe</option>
                  <option value="amina">Odor de amina</option>
                  <option value="adocicado_leve">Adocicado leve</option>
                  <option value="forte_apos_coito">Forte após coito</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-blue-800 mb-2">Consistência</label>
                <select
                  value={dischargeInfo.consistency}
                  onChange={(e) => setDischargeInfo({...dischargeInfo, consistency: e.target.value})}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="mucoso">Mucoso</option>
                  <option value="purulento">Purulento</option>
                  <option value="espesso">Espesso</option>
                  <option value="espumoso">Espumoso</option>
                  <option value="bolhoso">Bolhoso</option>
                  <option value="homogeneo">Homogêneo</option>
                  <option value="fluido">Fluido</option>
                  <option value="grumoso">Grumoso</option>
                  <option value="tipo_queijo_cottage">Tipo queijo cottage</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-blue-800 mb-2">Quantidade</label>
                <select
                  value={dischargeInfo.amount}
                  onChange={(e) => setDischargeInfo({...dischargeInfo, amount: e.target.value})}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="escasso">Escasso</option>
                  <option value="moderado">Moderado</option>
                  <option value="abundante">Abundante</option>
                  <option value="variavel">Variável</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Lesion Characteristics */}
        {symptoms.some(s => s.includes("lesao") || s.includes("vesiculas") || s.includes("erupcao") || s.includes("verrugas") || s.includes("gomas") || s.includes("aparecimento") || s.includes("manchas")) && (
          <div className="bg-red-50 p-6 rounded-xl border border-red-200">
            <h3 className="text-lg font-bold text-red-900 mb-4 flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
              Características das Lesões
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-red-800 mb-2">Tipo</label>
                <select
                  value={lesionInfo.type}
                  onChange={(e) => setLesionInfo({...lesionInfo, type: e.target.value})}
                  className="w-full px-3 py-2 border border-red-300 rounded-lg focus:ring-red-500 focus:border-red-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="ulcera">Úlcera</option>
                  <option value="cancro_duro">Cancro duro</option>
                  <option value="vesiculas">Vesículas</option>
                  <option value="ulceras_rasas">Úlceras rasas</option>
                  <option value="crostas">Crostas</option>
                  <option value="roséola_sifilítica">Roséola sifilítica</option>
                  <option value="sifílides_papulosas">Sifílides papulosas</option>
                  <option value="condiloma_plano">Condiloma plano</option>
                  <option value="manchas_planas">Manchas planas</option>
                  <option value="manchas_elevadas">Manchas elevadas</option>
                  <option value="gomas">Gomas</option>
                  <option value="ulceras_profundas">Úlceras profundas</option>
                  <option value="lesoes_destrutivas">Lesões destrutivas</option>
                  <option value="verrugas">Verrugas</option>
                  <option value="lesoes_vegetantes">Lesões vegetantes</option>
                  <option value="papulas_queratosicas">Pápulas queratósicas</option>
                  <option value="verrugas_pequenas">Verrugas pequenas</option>
                  <option value="verrugas_grandes">Verrugas grandes</option>
                  <option value="aspecto_couve_flor">Aspecto couve-flor</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-red-800 mb-2">Localização</label>
                <select
                  value={lesionInfo.location}
                  onChange={(e) => setLesionInfo({...lesionInfo, location: e.target.value})}
                  className="w-full px-3 py-2 border border-red-300 rounded-lg focus:ring-red-500 focus:border-red-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="genital">Genital</option>
                  <option value="anal">Anal</option>
                  <option value="oral">Oral</option>
                  <option value="perianal">Perianal</option>
                  <option value="boca">Boca</option>
                  <option value="palmas">Palmas das mãos</option>
                  <option value="plantas">Plantas dos pés</option>
                  <option value="tronco">Tronco</option>
                  <option value="face">Face</option>
                  <option value="mucosas">Mucosas</option>
                  <option value="couro_cabeludo">Couro cabeludo</option>
                  <option value="pele">Pele (geral)</option>
                  <option value="ossos">Ossos</option>
                  <option value="sistema_nervoso">Sistema nervoso</option>
                  <option value="cardiovascular">Cardiovascular</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-red-800 mb-2">Dor</label>
                <select
                  value={lesionInfo.pain === undefined ? "" : lesionInfo.pain.toString()}
                  onChange={(e) => setLesionInfo({...lesionInfo, pain: e.target.value === "" ? undefined : e.target.value === "true"})}
                  className="w-full px-3 py-2 border border-red-300 rounded-lg focus:ring-red-500 focus:border-red-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="true">Dolorosa</option>
                  <option value="false">Indolor</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-red-800 mb-2">Número</label>
                <select
                  value={lesionInfo.number}
                  onChange={(e) => setLesionInfo({...lesionInfo, number: e.target.value})}
                  className="w-full px-3 py-2 border border-red-300 rounded-lg focus:ring-red-500 focus:border-red-500 bg-white"
                >
                  <option value="">Selecione...</option>
                  <option value="unica">Única</option>
                  <option value="multiplas">Múltiplas</option>
                  <option value="agrupadas">Agrupadas</option>
                  <option value="disseminadas">Disseminadas</option>
                  <option value="coalescentes">Coalescentes</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Additional Symptoms */}
        <div>
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <svg className="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Sintomas Adicionais
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {additionalSymptomsOptions.map((symptom) => (
              <label key={symptom.id} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={additionalSymptoms.includes(symptom.id)}
                  onChange={(e) => handleAdditionalSymptomChange(symptom.id, e.target.checked)}
                  className="rounded border-gray-300 text-orange-600 focus:ring-orange-500 w-4 h-4"
                />
                <span className="text-lg">{symptom.icon}</span>
                <span className="text-sm font-medium text-gray-700">{symptom.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm font-bold text-gray-900 mb-2 flex items-center gap-2">
            <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
            Observações Adicionais (opcional)
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 resize-none"
            placeholder="Descreva outros achados relevantes, histórico clínico, ou observações importantes para o diagnóstico..."
          />
        </div>

        <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200">
          <button
            type="button"
            onClick={resetForm}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
          >
            Limpar Formulário
          </button>
          <button
            type="submit"
            className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-bold shadow-sm flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            Analisar Sintomas
          </button>
        </div>
      </form>
    </div>
  );
}
